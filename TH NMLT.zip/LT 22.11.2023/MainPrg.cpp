//ciel_23122013 23TNT1 FIT@HCMUS
// LT 22.11.2023

#include "phanso.h"

int main() {
	show();
	return 0;
}