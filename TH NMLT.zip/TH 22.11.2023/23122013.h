#ifndef _23122013_
#define _23122013_

//ciel_23122013 23TNT1 FIT@HCMUS
// TH NMLT 22.11.2023

#include <iostream>
#include <string>
#include <algorithm>
#include <stack>
#include <vector>

using namespace std;
typedef long long ll;

//prototype
//a
void section_a(ll n);
//b
void section_b(ll n);
void find_all_prime(ll n, vector<int>& a);
bool is_prime(ll x);
//cd
void section_cd(ll n);
bool is_palindrom(ll n);
//e
void section_e(ll n);
ll rev(ll n);

#endif