//ciel_23122013 23TNT1 FIT@HCMUS
// TH NMLT 22.11.2023

#include "23122013.h"

//main
int main() {
	ll n = 0;
	cout << "Nhap so nguyen N = ";
	cin >> n;
	section_a(n);
	section_b(n);
	section_cd(n);
	section_e(n);
	return 0;
}

